interface Shapes() {
	double area();
}

class Circle implements Shapes{
	static final double PI= 3.14;
	private double radius;
	
	Circle(){
		
	}
	
	Circle(double radius){
		this.radius=radius;	
	}
	
	public double getRadius() {
		return this.radius;
	}
	
	public double setRadius(double radius) {
	this.radius=radius;
	}
	
	
	public double area() {
		return this.PI * radius * radius;
		
	}
	
//	@Override
//	public String toString() {
//		return "Circle [radius=" + radius + ", area+  ]"
//	}
}


class Rectangle implements Shapes{
	private double length;
	private double breadth;
	
	Rectangle(){
		
	}
	
	Rectangle(double length,double breadth){
		this.length=length;
		this.breadth=breadth;
	}
	
	public double getLength() {
		return this.length;
	}
	
	public double setLength(double length) {
	this.length=length;
	}
	
	
	public double getBreadth() {
		return this.breadth;
	}
	
	public double setBreadth(double breadth) {
	this.breadth=breadth;
	}
	
	public double area() {
		return this.length * breadth;
		
	}
	
	@Override
	public String toString() {
		return "Rectangle [breadth="+breadth+",length="+length+"]"
	}
}

public class ShapesDriver{
	
public static void main(String args[]) {
	Shapes circle=new Circle(5);
	Shapes rectangle=new Rectangle(5,6);
	
	System.out.println(circle.area());
	System.out.println(rectangle.area());
}
}