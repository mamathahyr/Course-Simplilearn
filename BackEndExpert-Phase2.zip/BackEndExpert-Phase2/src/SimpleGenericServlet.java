import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;

public class SimpleGenericServlet extends GenericServlet {

	public void service(ServletRequest request, ServletResponse response ) throws ServletException, IOException{
	     String yesOrNoParam = request.getParameter("param");
	
	if("yes".equals(yesOrNoParam)) {
		response.getWriter().write(
			"<html><body>Thank you for subscribing</body></html>"
				);
}else {
	response.getWriter().write(
			"<html><body>You have not subscribed</body></html>"
			);
}
}
}