import java.util.Scanner; 

public class Program1 {
	     void findArea() {
		 Scanner s= new Scanner(System.in);
	        
        System.out.println("Enter the radius:");
        double r= s.nextDouble();
        double  area=(22*r*r)/7 ;
        System.out.println("Area of Circle is: " + area); 
		}

}
